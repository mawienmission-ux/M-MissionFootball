package com.mawienmission.mmissionfootball;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
